<?php

// Connection variables
  $servername = "lrgs.ftsm.ukm.my";
  $username = "a173630";
  $password = "biggraycamel";
  $dbname = "a173630";
  
?>

